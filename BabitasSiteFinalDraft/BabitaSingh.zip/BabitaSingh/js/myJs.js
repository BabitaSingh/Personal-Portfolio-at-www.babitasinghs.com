<form method="POST" action="http://formspree.io/basingh@syr.edu">
  <input type="email" name="email" placeholder="Your email">
  <textarea name="message" placeholder="Your message"></textarea>
  <button type="submit">Send Message</button>
</form>